 <!--==========================
    Header
  ============================-->
 <header id="header">
     <div class="container">

         <div id="logo" class="pull-left">

             <a href="#body"><img src="img/Logo-impro.png" alt="" title="" /></a>
         </div>

         <nav id="nav-menu-container">
             <ul class="nav-menu">
                 <li class="menu-active"><a href="#body">Inicio</a></li>
                 <li><a href="#about">Nosotros</a></li>
                 <li><a href="#services">Rubros</a></li>
                 <li><a href="#clients">Marcas</a></li>

            
                 <li><a href="#contact">Contáctanos</a></li>
             </ul>
         </nav><!-- #nav-menu-container -->
     </div>
 </header><!-- #header -->
<?php /**PATH F:\impro\impro1234\resources\views/layouts/IncludesLandingPage/landingNavbar.blade.php ENDPATH**/ ?>